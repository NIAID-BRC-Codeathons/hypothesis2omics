#!/usr/bin/env python3
"""
gcorr-prep -- CLI 1 of 3: ingest a feature matrix + sample metadata + an
outcome table, and emit a per-subject feature matrix aligned to a per-subject
outcome vector.

INPUT FORMAT (same shape as the YF-17D galaxy_file_input data, but nothing
about that study is hardcoded -- every column name is a flag):

  --matrix        features x samples. Row 1 = header: <id>,<sample1>,<sample2>...
                  Column 1 = feature id. CSV or TSV (sniffed, or --matrix-delim).
  --manifest      sample metadata, one row per sample column in the matrix.
                  Needs a sample-id column, a subject-id column, and (for
                  timepoint selection) a timepoint column.
  --outcome       one row per subject (optionally per subject x timepoint) with
                  the response value.

WHAT IT DOES (each step optional and explicit):
  1. filter samples by arbitrary metadata equality/substring  (--where)
  2. select timepoint(s), optionally as a fold change T - BASELINE
  3. collapse technical replicates per subject (mean|median|first)
  4. floor-filter low-signal features                          (--floor/--min-above)
  5. transform the outcome (none|log2|rank|zscore), optionally
     ranked WITHIN a grouping column to de-confound batch/arm
  6. intersect subjects, emit matrix + outcome + provenance

OUTPUT
  <out>.features.tsv   subjects x features   (observations as rows)
  <out>.outcome.tsv    subject <tab> value
  <out>.prep.json      provenance: every flag, input hashes, subject list

EXAMPLES
  # absolute timepoint, log2 outcome
  gcorr_prep.py --matrix expr.csv --manifest man.tsv --outcome titers.tsv \
      --sample-col repository_accession --subject-col subject_accession \
      --time-col study_time_collected --timepoint 7 \
      --outcome-subject-col subject_accession --outcome-value-col value_preferred \
      --outcome-time-col study_time_collected --outcome-timepoint 28 \
      --outcome-transform log2 --out out/d7

  # day7-day0 fold change, outcome ranked within arm (de-confounds arm)
  gcorr_prep.py ... --timepoint 7 --baseline 0 \
      --outcome-transform rank --rank-within arm_accession --out out/fc
"""
import argparse
import os
import statistics
import sys
from collections import defaultdict

try:                                    # installed as a package
    from galaxycorr.gcorr_common import (dump_json, provenance, read_dicts,
                                         read_table, require_cols, sha256,
                                         write_matrix)
except ImportError:                     # run directly as a script
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from gcorr_common import (dump_json, provenance, read_dicts, read_table,
                              require_cols, sha256, write_matrix)


def parse_where(exprs):
    """--where COL=VAL (exact) or COL~SUB (substring). Repeatable."""
    out = []
    for e in exprs or []:
        if "~" in e and ("=" not in e or e.index("~") < e.index("=")):
            c, v = e.split("~", 1); out.append((c, v, "sub"))
        elif "=" in e:
            c, v = e.split("=", 1); out.append((c, v, "eq"))
        else:
            sys.exit(f"error: --where must be COL=VAL or COL~SUBSTR, got {e!r}")
    return out


def collapse(vals, how):
    if how == "mean":
        return sum(vals) / len(vals)
    if how == "median":
        return statistics.median(vals)
    return vals[0]


def main():
    p = argparse.ArgumentParser(
        description="Prepare a feature matrix + outcome vector for correlation.",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)

    p.add_argument("--matrix", required=True)
    p.add_argument("--matrix-delim")
    p.add_argument("--manifest", required=True)
    p.add_argument("--manifest-delim")
    p.add_argument("--outcome", required=True)
    p.add_argument("--outcome-delim")
    p.add_argument("--out", required=True, help="output prefix")

    p.add_argument("--sample-col", required=True,
                   help="manifest column holding the matrix column ids")
    p.add_argument("--subject-col", required=True)
    p.add_argument("--time-col")
    p.add_argument("--timepoint", help="value in --time-col to analyse")
    p.add_argument("--baseline",
                   help="if set, emit (timepoint - baseline) per feature")
    p.add_argument("--where", action="append",
                   help="filter samples: COL=VAL or COL~SUBSTR (repeatable)")
    p.add_argument("--collapse", choices=["mean", "median", "first"],
                   default="mean", help="replicate collapse (default mean)")

    p.add_argument("--floor", type=float,
                   help="drop features not exceeding this in >= --min-above samples")
    p.add_argument("--min-above", type=int, default=1)
    p.add_argument("--floor-scope", choices=["filtered", "all"],
                   default="filtered",
                   help="evaluate the floor over the --where-filtered samples "
                        "(default) or over EVERY sample in the matrix. The "
                        "denominator changes which features survive, so "
                        "--min-above is only comparable within one scope.")

    p.add_argument("--outcome-subject-col", required=True)
    p.add_argument("--outcome-value-col", required=True)
    p.add_argument("--outcome-time-col")
    p.add_argument("--outcome-timepoint")
    p.add_argument("--outcome-where", action="append")
    p.add_argument("--outcome-transform",
                   choices=["none", "log2", "rank", "zscore"], default="none")
    p.add_argument("--rank-within",
                   help="manifest column; percentile-rank the outcome WITHIN each "
                        "group (de-confounds arm/batch). Requires --outcome-transform rank")
    p.add_argument("--min-subjects", type=int, default=3)
    args = p.parse_args()

    if args.rank_within and args.outcome_transform != "rank":
        sys.exit("error: --rank-within requires --outcome-transform rank")
    if args.baseline is not None and not args.time_col:
        sys.exit("error: --baseline requires --time-col")
    if args.timepoint is not None and not args.time_col:
        sys.exit("error: --timepoint requires --time-col")

    # ---------------------------------------------------------------- manifest
    man_rows = read_dicts(args.manifest, args.manifest_delim)
    if not man_rows:
        sys.exit(f"error: {args.manifest} has no data rows")
    mcols = list(man_rows[0].keys())
    require_cols(args.manifest, mcols,
                 [args.sample_col, args.subject_col, args.time_col,
                  args.rank_within] + [c for c, _, _ in parse_where(args.where)])

    wh = parse_where(args.where)
    man = {}
    for r in man_rows:
        ok = all((r.get(c, "") == v) if k == "eq" else (v in r.get(c, ""))
                 for c, v, k in wh)
        if ok:
            man[r[args.sample_col]] = r

    # ------------------------------------------------------------------ matrix
    header, rows = read_table(args.matrix, args.matrix_delim)
    samples = header[1:]
    usable = [s for s in samples if s in man]
    # samples the floor is evaluated over -- may be wider than `usable`
    all_known = [s for s in samples
                 if any(r.get(args.sample_col) == s for r in man_rows)]
    floor_samples = all_known if args.floor_scope == "all" else usable
    if not usable:
        sys.exit("error: no matrix columns survived --where / matched --sample-col.\n"
                 f"       matrix columns look like: {samples[:3]}\n"
                 f"       manifest {args.sample_col} looks like: "
                 f"{[r[args.sample_col] for r in man_rows[:3]]}")
    idx = {s: i + 1 for i, s in enumerate(samples)}

    def numeric(r, cols):
        """-> list of floats, or None if any value is missing/non-numeric."""
        out = []
        for s in cols:
            x = r[idx[s]].strip()
            if x == "" or x.upper() in ("NA", "NAN", "NULL"):
                return None
            try:
                out.append(float(x))
            except ValueError:
                return None
        return out

    feat_ids, mat = [], []
    dropped_nan = 0
    dropped_floor = 0
    for r in rows:
        vals = numeric(r, usable)
        if vals is None:
            dropped_nan += 1; continue
        if args.floor is not None:
            fv = (vals if floor_samples is usable
                  else numeric(r, floor_samples))
            if fv is None:
                dropped_nan += 1; continue
            if sum(1 for x in fv if x > args.floor) < args.min_above:
                dropped_floor += 1; continue
        feat_ids.append(r[0]); mat.append(vals)
    if not feat_ids:
        sys.exit("error: all features filtered out; relax --floor/--min-above")

    scol = {s: j for j, s in enumerate(usable)}

    def per_subject(tp):
        """-> {subject: [feature values]} collapsing replicates at timepoint tp."""
        buckets = defaultdict(list)
        for s in usable:
            if tp is not None and man[s].get(args.time_col, "") != tp:
                continue
            buckets[man[s][args.subject_col]].append(scol[s])
        out = {}
        for subj, cols in buckets.items():
            out[subj] = [collapse([mat[i][c] for c in cols], args.collapse)
                         for i in range(len(feat_ids))]
        return out

    at_tp = per_subject(args.timepoint)
    if args.baseline is not None:
        base = per_subject(args.baseline)
        subs = sorted(set(at_tp) & set(base))
        feats = {s: [a - b for a, b in zip(at_tp[s], base[s])] for s in subs}
        feature_desc = f"{args.timepoint} minus {args.baseline}"
    else:
        feats = at_tp
        feature_desc = (f"timepoint {args.timepoint}" if args.timepoint
                        else "all samples")

    # ----------------------------------------------------------------- outcome
    out_rows = read_dicts(args.outcome, args.outcome_delim)
    if not out_rows:
        sys.exit(f"error: {args.outcome} has no data rows")
    require_cols(args.outcome, list(out_rows[0].keys()),
                 [args.outcome_subject_col, args.outcome_value_col,
                  args.outcome_time_col]
                 + [c for c, _, _ in parse_where(args.outcome_where)])
    owh = parse_where(args.outcome_where)

    yraw = {}
    for r in out_rows:
        if args.outcome_time_col and args.outcome_timepoint is not None:
            if r.get(args.outcome_time_col, "") != args.outcome_timepoint:
                continue
        if not all((r.get(c, "") == v) if k == "eq" else (v in r.get(c, ""))
                   for c, v, k in owh):
            continue
        v = (r.get(args.outcome_value_col) or "").strip()
        if v == "":
            continue
        try:
            yraw.setdefault(r[args.outcome_subject_col], float(v))
        except ValueError:
            continue

    subs = sorted(set(feats) & set(yraw))
    if len(subs) < args.min_subjects:
        sys.exit(f"error: only {len(subs)} subject(s) have BOTH features and an "
                 f"outcome (need >= {args.min_subjects}).\n"
                 f"       features: {len(feats)}  outcome: {len(yraw)}\n"
                 f"       Check --timepoint / --outcome-timepoint / --where.")

    # transform
    import math
    if args.outcome_transform == "log2":
        bad = [s for s in subs if yraw[s] <= 0]
        if bad:
            sys.exit(f"error: --outcome-transform log2 but {len(bad)} subject(s) "
                     f"have value <= 0 (e.g. {bad[:3]})")
        y = {s: math.log2(yraw[s]) for s in subs}
    elif args.outcome_transform == "zscore":
        mu = statistics.fmean(yraw[s] for s in subs)
        sd = statistics.pstdev([yraw[s] for s in subs]) or 1.0
        y = {s: (yraw[s] - mu) / sd for s in subs}
    elif args.outcome_transform == "rank":
        groups = defaultdict(list)
        for s in subs:
            g = (man_by_subject(man, args.subject_col, s, args.rank_within)
                 if args.rank_within else "_all")
            groups[g].append(s)
        y = {}
        for g, ss in groups.items():
            order = sorted(ss, key=lambda s: yraw[s])
            # average ranks for ties, then percentile
            i = 0
            while i < len(order):
                j = i
                while j + 1 < len(order) and yraw[order[j + 1]] == yraw[order[i]]:
                    j += 1
                avg = (i + j) / 2.0 + 1.0
                for k in range(i, j + 1):
                    y[order[k]] = (avg - 0.5) / len(order)
                i = j + 1
    else:
        y = {s: yraw[s] for s in subs}

    if len(set(round(y[s], 12) for s in subs)) == 1:
        sys.exit("error: outcome is constant across subjects -- correlation undefined.")

    # ------------------------------------------------------------------ write
    fpath = args.out + ".features.tsv"
    opath = args.out + ".outcome.tsv"
    write_matrix(fpath, subs, feat_ids, lambda i: feats[subs[i]],
                 id_header="subject")
    os.makedirs(os.path.dirname(os.path.abspath(opath)) or ".", exist_ok=True)
    with open(opath, "w") as f:
        f.write("subject\toutcome\n")
        for s in subs:
            f.write(f"{s}\t{y[s]:.12g}\n")

    rec = provenance(
        "gcorr-prep", args,
        inputs={"matrix": {"path": args.matrix, "sha256": sha256(args.matrix)},
                "manifest": {"path": args.manifest,
                             "sha256": sha256(args.manifest)},
                "outcome": {"path": args.outcome,
                            "sha256": sha256(args.outcome)}},
        outputs={"features": {"path": fpath, "sha256": sha256(fpath)},
                 "outcome": {"path": opath, "sha256": sha256(opath)}},
        extra={"n_subjects": len(subs), "n_features": len(feat_ids),
               "subjects": subs, "feature_definition": feature_desc,
               "dropped_features_missing_values": dropped_nan,
               "dropped_features_floor": dropped_floor,
               "floor_evaluated_over_n_samples": (len(floor_samples)
                                                  if args.floor is not None
                                                  else None),
               "analysis_samples_n": len(usable),
               "outcome_values": {s: y[s] for s in subs},
               "outcome_raw": {s: yraw[s] for s in subs}})
    jpath = dump_json(args.out + ".prep.json", rec)

    print(f"[prep] features : {fpath}  ({len(subs)} subjects x {len(feat_ids)} features)")
    print(f"[prep] outcome  : {opath}  (transform={args.outcome_transform}"
          f"{', within ' + args.rank_within if args.rank_within else ''})")
    if args.floor is not None:
        print(f"[prep] floor    : >{args.floor} in >={args.min_above} of "
              f"{len(floor_samples)} sample(s) [scope={args.floor_scope}]")
    print(f"[prep] dropped  : {dropped_nan} missing-value, {dropped_floor} floor")
    print(f"[prep] feature  : {feature_desc}")
    print(f"[prep] prov     : {jpath}")


def man_by_subject(man, subject_col, subj, col):
    for r in man.values():
        if r[subject_col] == subj:
            return r.get(col, "")
    return ""


if __name__ == "__main__":
    main()
