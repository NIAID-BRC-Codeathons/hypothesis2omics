#!/usr/bin/env python3
"""
gcorr-broadcast -- CLI 2 of 3: turn a features matrix + a single outcome vector
into the MATCHED MATRIX PAIR that a feature-wise correlation tool consumes.

WHY THIS EXISTS
The Galaxy tool `Feature-wise Correlation Tests` correlates feature f in matrix
A against feature f in matrix B -- matrix vs matrix, pairing features BY NAME
when headers are present. Our question is matrix vs ONE vector. The reduction:

    matrix A = subjects x features          (unchanged)
    matrix B = subjects x features, where EVERY column is the same outcome vector

Feature-wise correlation then evaluates Spearman(feature_i, outcome) for each i,
which is exactly the intended per-feature test. This is a deliberate encoding,
recorded in the provenance as such -- not a property of the tool.

COST NOTE: matrix B is |subjects| x |features| of a repeated value, so it is
roughly the size of matrix A on disk. That is the price of expressing a
vector comparison on a matrix-vs-matrix interface.

INPUT   the two files written by gcorr-prep (or any files of that shape):
          features.tsv : subject <tab> f1 <tab> f2 ...
          outcome.tsv  : subject <tab> value
OUTPUT  <out>.matA.tsv, <out>.matB.tsv, <out>.broadcast.json

EXAMPLE
  gcorr_broadcast.py --features out/fc.features.tsv \
                     --outcome  out/fc.outcome.tsv  --out out/fc
"""
import argparse
import os
import sys

try:                                    # installed as a package
    from galaxycorr.gcorr_common import (dump_json, provenance, read_table,
                                         sha256, write_matrix)
except ImportError:                     # run directly as a script
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from gcorr_common import (dump_json, provenance, read_table, sha256,
                              write_matrix)


def main():
    p = argparse.ArgumentParser(
        description="Broadcast an outcome vector into a matched matrix pair.",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--features", required=True,
                   help="subjects x features TSV (row 1 header, col 1 subject id)")
    p.add_argument("--outcome", required=True,
                   help="TSV: subject <tab> value (header row expected)")
    p.add_argument("--out", required=True, help="output prefix")
    p.add_argument("--outcome-col", default=None,
                   help="name of the value column (default: 2nd column)")
    p.add_argument("--no-header-outcome", action="store_true",
                   help="outcome file has no header row")
    args = p.parse_args()

    fhdr, frows = read_table(args.features, "\t")
    feat_ids = fhdr[1:]
    subs = [r[0] for r in frows]
    if not feat_ids:
        sys.exit("error: features file has no feature columns")
    if len(set(subs)) != len(subs):
        sys.exit("error: duplicate subject ids in features file")

    # outcome
    if args.no_header_outcome:
        orows = [r for r in read_table(args.outcome, "\t")[1]]
        ohdr = None
        first = read_table(args.outcome, "\t")[0]
        orows = [first] + orows
        vcol = 1
    else:
        ohdr, orows = read_table(args.outcome, "\t")
        vcol = 1
        if args.outcome_col:
            if args.outcome_col not in ohdr:
                sys.exit(f"error: --outcome-col {args.outcome_col!r} not in "
                         f"{ohdr}")
            vcol = ohdr.index(args.outcome_col)

    y = {}
    for r in orows:
        if len(r) <= vcol or r[vcol].strip() == "":
            continue
        try:
            y[r[0]] = float(r[vcol])
        except ValueError:
            sys.exit(f"error: non-numeric outcome for subject {r[0]!r}: {r[vcol]!r}")

    missing = [s for s in subs if s not in y]
    if missing:
        sys.exit(f"error: {len(missing)} subject(s) in the features matrix have no "
                 f"outcome value (e.g. {missing[:5]}).\n"
                 "       gcorr-prep emits an already-intersected pair; if you built "
                 "these by hand, intersect them first.")
    if len(set(round(y[s], 12) for s in subs)) == 1:
        sys.exit("error: outcome is constant -- correlation is undefined.")

    a = args.out + ".matA.tsv"
    b = args.out + ".matB.tsv"
    fvals = {r[0]: [float(x) for x in r[1:]] for r in frows}
    write_matrix(a, subs, feat_ids, lambda i: fvals[subs[i]], id_header="subject")
    write_matrix(b, subs, feat_ids,
                 lambda i: [y[subs[i]]] * len(feat_ids), id_header="subject")

    rec = provenance(
        "gcorr-broadcast", args,
        inputs={"features": {"path": args.features,
                             "sha256": sha256(args.features)},
                "outcome": {"path": args.outcome,
                            "sha256": sha256(args.outcome)}},
        outputs={"matrix_a": {"path": a, "sha256": sha256(a),
                              "bytes": os.path.getsize(a)},
                 "matrix_b": {"path": b, "sha256": sha256(b),
                              "bytes": os.path.getsize(b)}},
        extra={"n_subjects": len(subs), "n_features": len(feat_ids),
               "subjects": subs,
               "encoding_note": ("matrix B replicates the single outcome vector "
                                 "across every feature column so that feature-wise "
                                 "correlation reduces to feature-vs-outcome")})
    j = dump_json(args.out + ".broadcast.json", rec)

    print(f"[broadcast] matA : {a}  ({len(subs)} x {len(feat_ids)})")
    print(f"[broadcast] matB : {b}  (outcome replicated across {len(feat_ids)} cols)")
    print(f"[broadcast] prov : {j}")


if __name__ == "__main__":
    main()
