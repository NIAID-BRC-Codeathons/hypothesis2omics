#!/usr/bin/env python3
"""Shared helpers for the gcorr-* CLIs (hashing, TSV/CSV IO, provenance)."""
import csv
import hashlib
import json
import os
import subprocess
import sys
import time

# Text precision for emitted matrices. MUST be round-trip lossless for float64:
# %.17g guarantees that, %.12g does NOT. This matters far more than it looks.
# On 2-decimal-place source data (e.g. GSE13699), fold-change differences that
# are genuinely distinct in float64 print identically at %.12g, MANUFACTURING
# ties that are not in the data. Spearman then averages ranks over those false
# ties and returns a different rho. Measured on GSE13699 d7-d0: %.12g corrupts
# the tie structure of 2,038/22,177 probes (9.2%), %.15g of 111 (0.5%), %.17g
# of 0. See notebook Session 10.
FMT = "%.17g"
SCHEMA = "gcorr/2"     # provenance schema tag (v2: %.17g matrix serialization)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sniff(path, override=None):
    """Delimiter for a table. Explicit override wins; else by extension."""
    if override:
        return {"tab": "\t", "comma": ",", "\\t": "\t"}.get(override, override)
    return "," if path.lower().endswith((".csv", ".csv.gz")) else "\t"


def read_table(path, delim=None):
    """-> (header:list[str], rows:list[list[str]]). Blank lines skipped."""
    d = sniff(path, delim)
    with open(path, newline="") as f:
        rdr = csv.reader(f, delimiter=d)
        header = next(rdr)
        rows = [r for r in rdr if r and any(x.strip() for x in r)]
    return header, rows


def read_dicts(path, delim=None):
    d = sniff(path, delim)
    with open(path, newline="") as f:
        return list(csv.DictReader(f, delimiter=d))


def require_cols(path, have, want):
    missing = [c for c in want if c and c not in have]
    if missing:
        sys.exit(f"error: {path} is missing column(s): {', '.join(missing)}\n"
                 f"       available: {', '.join(have[:25])}"
                 f"{' ...' if len(have) > 25 else ''}")


def write_matrix(path, row_ids, col_ids, get_row, id_header="sample"):
    """Write an observations-as-rows matrix (the layout the Galaxy tool reads)."""
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", newline="") as f:
        f.write(id_header + "\t" + "\t".join(col_ids) + "\n")
        for i, rid in enumerate(row_ids):
            f.write(rid + "\t" + "\t".join(FMT % v for v in get_row(i)) + "\n")


def git_rev():
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return None


def provenance(tool, args_namespace, inputs, outputs, extra=None):
    """Uniform provenance record written next to every CLI's outputs."""
    rec = {
        "schema": SCHEMA,
        "tool": tool,
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "argv": sys.argv,
        "args": {k: v for k, v in vars(args_namespace).items()},
        "python": sys.version.split()[0],
        "git_rev": git_rev(),
        "inputs": inputs,
        "outputs": outputs,
    }
    if extra:
        rec.update(extra)
    return rec


def dump_json(path, obj):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
    return path
