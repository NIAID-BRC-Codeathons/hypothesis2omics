#!/usr/bin/env python3
"""Audit tie structure in a gcorr-prep features file, and optionally diff a
fresh Spearman recomputation against a stored reference table.

usage:  python3 check_ties.py <prefix>.features.tsv [stored_corr.tsv]

WHY THIS MATTERS (notebook Session 10): on low-precision source data, feature
values that are genuinely distinct in float64 can print identically if the
matrix is written with too few digits -- manufacturing ties that are not in
the data. Spearman then averages ranks over those false ties and returns a
different rho. gcorr writes %.17g (round-trip lossless) to prevent this; a
high tie fraction here tells you the dataset is one where that choice bites.

The stored-table diff expects columns probe_id/rho and is matched BY ID,
never positionally.
"""
import csv
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np
from scipy import stats

feat_path = sys.argv[1]
stored_path = sys.argv[2] if len(sys.argv) > 2 else None
out_path = feat_path.replace(".features.tsv", ".outcome.tsv")

rows = list(csv.reader(open(feat_path), delimiter="\t"))
feats = rows[0][1:]
X = np.array([[float(x) for x in r[1:]] for r in rows[1:]])
n, m = X.shape

ties = sum(1 for j in range(m) if len(set(X[:, j])) < n)
print(f"{feat_path}: {n} subjects x {m} features")
print(f"  features containing tied values: {ties} ({100*ties/m:.1f}%)")
print("  -> ties present: rho depends on how they are broken, so the matrix\n"
      "     must be serialized losslessly (%.17g). See notebook Session 10."
      if ties else "  -> no ties; rho is insensitive to serialization here")

if stored_path:
    y = np.array([float(l.split("\t")[1])
                  for l in open(out_path).read().splitlines()[1:]])
    rho = np.array([stats.spearmanr(X[:, j], y).statistic for j in range(m)])
    stored = {r["probe_id"]: float(r["rho"])
              for r in csv.DictReader(open(stored_path), delimiter="\t")}
    missing = [f for f in feats if f not in stored]
    if missing:
        sys.exit(f"  {len(missing)} feature(s) absent from stored table, e.g. {missing[:3]}")
    o = np.array([stored[f] for f in feats])        # ID-matched, never positional
    d = np.nan_to_num(np.abs(rho - o))
    print(f"\n  vs {stored_path}")
    print(f"    max |delta rho|    = {d.max():.4f}")
    print(f"    median |delta rho| = {np.median(d):.4f}")
    print(f"    features shifting > 0.01 : {(d > 0.01).sum()} / {m}")
