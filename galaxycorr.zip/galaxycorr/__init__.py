"""galaxycorr -- feature-wise correlation on Galaxy, in three stages.

  gcorr-prep       raw matrix + manifest + outcome -> features.tsv + outcome.tsv
  gcorr-broadcast  features + outcome             -> matA.tsv + matB.tsv
  gcorr-run        two matrices                   -> Galaxy job -> results

Each stage writes a provenance JSON (schema "gcorr/1") carrying full argv,
resolved flags, input/output sha256s, python version and git rev.
"""
__version__ = "0.1.0"
