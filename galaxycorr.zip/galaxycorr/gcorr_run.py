#!/usr/bin/env python3
"""
gcorr-run -- CLI 3 of 3: run a feature-wise correlation tool on Galaxy against
ANY two matched matrices, download the results, and write provenance.

Generalized from yf17d/run_galaxy_correlation.py: takes explicit matrix PATHS
(not an analysis key), exposes every tool parameter as a flag, and makes the
comparison against a local reference optional with configurable column names.

CREDENTIALS come from the environment only -- never pass a key on the command
line (it would land in your shell history and in this tool's own provenance
`argv`):
    export GALAXY_URL=https://usegalaxy.org
    export GALAXY_API_KEY=<key>

OUTPUT
  <out>.per_feature.tsv   per-feature statistic / p / adjusted p
  <out>.summary.tsv       tool's run summary
  <out>.run.json          provenance: tool id+params, history/job ids, hashes,
                          and the comparison verdict when --compare-to is given

EXAMPLES
  gcorr_run.py --matrix-a out/fc.matA.tsv --matrix-b out/fc.matB.tsv \
               --out results/fc --history-name "my correlation run"

  # spearman is the default; switch method / adjust alpha:
  gcorr_run.py ... --method pearson --alpha 0.01

  # regression-check against a local reference table:
  gcorr_run.py ... --compare-to local.tsv \
      --ref-id-col probe_id --ref-stat-col rho --ref-p-col p --ref-q-col q_BH
"""
import argparse
import os
import sys
import time

try:                                    # installed as a package
    from galaxycorr.gcorr_common import (dump_json, provenance, read_dicts,
                                         sha256)
except ImportError:                     # run directly as a script
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from gcorr_common import dump_json, provenance, read_dicts, sha256

DEFAULT_TOOL = ("toolshed.g2.bx.psu.edu/repos/goeckslab/featurewise_correlation/"
                "featurewise_correlation/0.1.0+galaxy3")


def connect(url):
    try:
        from bioblend.galaxy import GalaxyInstance
    except ImportError:
        sys.exit("error: bioblend is not installed.\n"
                 "       python3 -m pip install --user bioblend")
    key = os.environ.get("GALAXY_API_KEY")
    if not key:
        sys.exit("error: GALAXY_API_KEY is not set in the environment.\n"
                 "       export it; do not pass keys as CLI arguments.")
    gi = GalaxyInstance(url=url, key=key)
    try:
        me = gi.users.get_current_user()
    except Exception as e:
        sys.exit(f"error: could not authenticate to {url}: {e}")
    print(f"[galaxy] {url} as {me['username']} ({me['nice_total_disk_usage']} used)")
    return gi


def upload(gi, hid, path, name, poll):
    r = gi.tools.upload_file(path, hid, file_name=name, file_type="tabular")
    ds_id = r["outputs"][0]["id"]
    while True:
        ds = gi.datasets.show_dataset(ds_id)
        if ds["state"] in ("ok", "error"):
            break
        time.sleep(poll)
    if ds["state"] != "ok":
        sys.exit(f"error: upload failed for {name} (state={ds['state']})")
    print(f"[upload] hid {ds['hid']:>2}  {name}  ({ds['file_size']} bytes)")
    return ds_id


def compare(galaxy_tsv, ref_tsv, idc, statc, pc, qc):
    gx = {r["feature"]: r for r in read_dicts(galaxy_tsv, "\t")}
    ref = read_dicts(ref_tsv, "\t")
    if not ref:
        return {"error": "reference table has no rows"}
    for c in [idc, statc, pc] + ([qc] if qc else []):
        if c not in ref[0]:
            return {"error": f"reference is missing column {c!r}; "
                             f"has {list(ref[0].keys())}"}
    lo = {r[idc]: r for r in ref}
    if set(gx) != set(lo):
        return {"feature_sets_identical": False,
                "n_galaxy": len(gx), "n_reference": len(lo),
                "only_in_galaxy": sorted(set(gx) - set(lo))[:5],
                "only_in_reference": sorted(set(lo) - set(gx))[:5]}
    keys = sorted(lo)
    d_s = max(abs(float(gx[k]["statistic"]) - float(lo[k][statc])) for k in keys)
    d_p = max(abs(float(gx[k]["p_value"]) - float(lo[k][pc])) for k in keys)
    out = {"feature_sets_identical": True, "n_features": len(keys),
           "max_abs_statistic_diff": d_s, "max_abs_p_diff": d_p}
    if qc:
        out["max_abs_q_diff"] = max(
            abs(float(gx[k]["p_adjust_bh"]) - float(lo[k][qc])) for k in keys)
    g_by_p = sorted(keys, key=lambda k: float(gx[k]["p_value"]))
    l_by_p = sorted(keys, key=lambda k: float(lo[k][pc]))
    top = min(1000, len(keys))
    out[f"top{top}_overlap"] = len(set(g_by_p[:top]) & set(l_by_p[:top]))
    out["galaxy_significant_true"] = sum(
        1 for k in keys if gx[k].get("significant") == "true")
    out["top_hit_galaxy"] = {"feature": g_by_p[0],
                             "statistic": float(gx[g_by_p[0]]["statistic"]),
                             "p": float(gx[g_by_p[0]]["p_value"])}
    return out


def main():
    p = argparse.ArgumentParser(
        description="Run a feature-wise correlation tool on Galaxy.",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--matrix-a", required=True)
    p.add_argument("--matrix-b", required=True)
    p.add_argument("--out", required=True, help="output prefix")

    p.add_argument("--galaxy-url",
                   default=os.environ.get("GALAXY_URL", "https://usegalaxy.org"))
    p.add_argument("--tool-id", default=DEFAULT_TOOL)
    p.add_argument("--history-id", help="reuse an existing history")
    p.add_argument("--history-name")
    p.add_argument("--poll", type=int, default=5, help="seconds between polls")
    p.add_argument("--timeout", type=int, default=7200,
                   help="give up waiting after N seconds (default 7200)")

    p.add_argument("--method", default="spearman",
                   choices=["spearman", "pearson"])
    p.add_argument("--alternative", default="two-sided",
                   choices=["two-sided", "less", "greater"])
    p.add_argument("--alpha", type=float, default=0.05)
    p.add_argument("--min-pairs", type=int, default=3)
    p.add_argument("--delimiter", default="tab", choices=["tab", "comma"])
    p.add_argument("--no-header", action="store_true")
    p.add_argument("--id-column", type=int, default=1)
    p.add_argument("--feature-start", type=int, default=2)
    p.add_argument("--transform", default="none")

    p.add_argument("--compare-to", help="local reference TSV for a regression check")
    p.add_argument("--ref-id-col", default="feature")
    p.add_argument("--ref-stat-col", default="statistic")
    p.add_argument("--ref-p-col", default="p_value")
    p.add_argument("--ref-q-col", default=None)
    p.add_argument("--fail-on-mismatch", action="store_true",
                   help="exit non-zero if the comparison does not agree")
    p.add_argument("--tolerance", type=float, default=1e-5)
    args = p.parse_args()

    for f in (args.matrix_a, args.matrix_b):
        if not os.path.exists(f):
            sys.exit(f"error: no such file: {f}")
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)

    hdr = "false" if args.no_header else "true"
    tool_params = {
        "delimiter_a": args.delimiter, "delimiter_b": args.delimiter,
        "has_header_a": hdr, "has_header_b": hdr,
        "id_column_a": args.id_column, "id_column_b": args.id_column,
        "feature_start_a": args.feature_start,
        "feature_start_b": args.feature_start,
        "transform_a": args.transform, "transform_b": args.transform,
        "method": args.method, "alternative": args.alternative,
        "alpha": args.alpha, "min_pairs": args.min_pairs,
    }

    gi = connect(args.galaxy_url)
    if args.history_id:
        hid = args.history_id
        print(f"[history] reusing {hid}")
    else:
        name = args.history_name or f"gcorr {args.method} {os.path.basename(args.out)}"
        hid = gi.histories.create_history(name=name)["id"]
        print(f"[history] created {hid}  {name}")

    a_id = upload(gi, hid, args.matrix_a, os.path.basename(args.matrix_a), args.poll)
    b_id = upload(gi, hid, args.matrix_b, os.path.basename(args.matrix_b), args.poll)

    inputs = dict(tool_params)
    inputs["matrix_a"] = {"src": "hda", "id": a_id}
    inputs["matrix_b"] = {"src": "hda", "id": b_id}
    run = gi.tools.run_tool(hid, args.tool_id, inputs)
    job_id = run["jobs"][0]["id"]
    pf_id = next(o["id"] for o in run["outputs"] if o["output_name"] == "per_feature")
    sm_id = next(o["id"] for o in run["outputs"] if o["output_name"] == "summary")
    print(f"[job] submitted {job_id}")

    t0 = time.time()
    while True:
        job = gi.jobs.show_job(job_id)
        if job["state"] in ("ok", "error", "deleted", "paused"):
            break
        if time.time() - t0 > args.timeout:
            sys.exit(f"error: timed out after {args.timeout}s; job {job_id} is "
                     f"still {job['state']}. Inspect it in Galaxy.")
        print(f"[job] {job['state']} ...")
        time.sleep(args.poll)
    print(f"[job] finished state={job['state']} exit_code={job.get('exit_code')}")
    if job["state"] != "ok":
        sys.exit(f"error: job {job_id} did not succeed")

    pf = args.out + ".per_feature.tsv"
    sm = args.out + ".summary.tsv"
    with open(pf, "wb") as f:
        f.write(gi.datasets.download_dataset(pf_id))
    with open(sm, "wb") as f:
        f.write(gi.datasets.download_dataset(sm_id))
    print(f"[download] {pf}")
    print(f"[download] {sm}")
    print("\n--- summary ---")
    print(open(sm).read().strip())

    extra = {"history_id": hid, "job_id": job_id, "job_state": job["state"],
             "galaxy_url": args.galaxy_url, "tool_id": args.tool_id,
             "tool_params": tool_params}
    agree = None
    if args.compare_to:
        cmp = compare(pf, args.compare_to, args.ref_id_col, args.ref_stat_col,
                      args.ref_p_col, args.ref_q_col)
        extra["comparison"] = cmp
        extra["reference"] = args.compare_to
        print("\n--- comparison vs reference ---")
        import json as _j
        print(_j.dumps(cmp, indent=2))
        agree = (cmp.get("feature_sets_identical")
                 and cmp.get("max_abs_statistic_diff", 1) < args.tolerance
                 and cmp.get("max_abs_p_diff", 1) < args.tolerance
                 and (args.ref_q_col is None
                      or cmp.get("max_abs_q_diff", 1) < args.tolerance))
        extra["agrees_with_reference"] = bool(agree)
        print(f"\nAGREEMENT: {'PASS' if agree else 'FAIL'}")

    # honest read of the tool's own verdict
    nsig = None
    for line in open(sm):
        if line.startswith("significant_count"):
            nsig = line.split("\t")[1].strip()
    if nsig == "0":
        print("NOTE: significant_count=0 -- no feature passes the adjusted-p "
              "threshold. Agreement (if checked) confirms arithmetic, not a finding.")

    rec = provenance(
        "gcorr-run", args,
        inputs={"matrix_a": {"path": args.matrix_a,
                             "sha256": sha256(args.matrix_a)},
                "matrix_b": {"path": args.matrix_b,
                             "sha256": sha256(args.matrix_b)}},
        outputs={"per_feature": {"path": pf, "sha256": sha256(pf)},
                 "summary": {"path": sm, "sha256": sha256(sm)}},
        extra=extra)
    print(f"[provenance] {dump_json(args.out + '.run.json', rec)}")

    if args.compare_to and args.fail_on_mismatch and not agree:
        sys.exit(2)


if __name__ == "__main__":
    main()
