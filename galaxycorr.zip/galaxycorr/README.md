# galaxycorr — three CLIs for feature-wise correlation on Galaxy

Generalized from `yf17d/run_galaxy_correlation.py`. Nothing about YF-17D,
ImmPort, or GEO is hardcoded: every column name, filter, and tool parameter is
a flag. The YF-17D pipeline is reproducible as one invocation of each CLI
(verified — see *Test it yourself* below).

```
  raw inputs                  gcorr-prep         gcorr-broadcast      gcorr-run
  ──────────                  ──────────         ───────────────      ─────────
  features x samples   ──┐
  sample manifest      ──┼──▶  features.tsv  ──▶  matA.tsv       ──▶  per_feature.tsv
  outcome table        ──┘     outcome.tsv   ──▶  matB.tsv       ──▶  summary.tsv
                               prep.json          broadcast.json      run.json
```

Each stage writes a provenance JSON (`schema: gcorr/2`) carrying the full
`argv`, every resolved flag, input/output sha256s, python version and git rev.
The chain of three JSONs is a complete audit trail from raw file to result.

### Numerical precision — why matrices are written at `%.17g`

Matrices are serialized with `%.17g`, which is **round-trip lossless for
float64**. This is not cosmetic. On low-precision source data (e.g. intensities
stored to 2 decimal places), fold-change values that are genuinely *distinct*
in float64 print *identically* at lower precision — **manufacturing ties that
are not in the data**. Spearman then averages ranks across those false ties and
returns a different rho.

Measured on GSE13699 d7−d0, 22,177 probes:

| format | probes whose tie structure is corrupted |
|---|---|
| `%.12g` | **2,038 (9.2%)** |
| `%.15g` | 111 (0.5%) |
| `%.17g` | **0** |

With `%.12g` one probe's rho moved 0.327 → 0.248. Do not lower `FMT` in
`gcorr_common.py`.

## Install

```bash
python3 -m pip install --user bioblend      # only gcorr-run needs it
export GALAXY_URL=https://usegalaxy.org
export GALAXY_API_KEY=<your key>            # environment only, never a CLI flag
```

## CLI 1 — `gcorr_prep.py`

Ingest raw data, produce a per-subject feature matrix + aligned outcome vector.

| Step | Flags |
|---|---|
| filter samples | `--where COL=VAL` / `--where COL~SUBSTR` (repeatable) |
| pick timepoint | `--time-col --timepoint` |
| fold change | `--baseline` → emits `(timepoint − baseline)` |
| collapse replicates | `--collapse mean\|median\|first` |
| floor filter | `--floor X --min-above N --floor-scope {filtered,all}` |
| outcome selection | `--outcome-subject-col --outcome-value-col --outcome-time-col --outcome-timepoint --outcome-where` |
| outcome transform | `--outcome-transform none\|log2\|rank\|zscore` |
| de-confound | `--rank-within COL` (percentile-rank within each group) |

`--rank-within` is the de-confounding tool: when the outcome is entangled with
a batch/arm/site variable, ranking within that group removes the group effect
before correlation.

**`--floor-scope` changes the denominator, and you must choose deliberately.**
`--min-above N` counts samples exceeding the floor, but *which* samples?

- `filtered` (default) — only the samples surviving `--where`.
- `all` — every sample in the matrix, including those `--where` excludes.

On cohort B this is 8,741 features vs 8,914 from the same `--floor 7.0
--min-above 13`, because the floor sees 93 arrays instead of 126. Neither is
wrong, but `--min-above` is only comparable within one scope, so `gcorr-prep`
prints the denominator it used on every run.

## CLI 2 — `gcorr_broadcast.py`

Turns *matrix vs one vector* into the *matrix vs matrix* pair the Galaxy tool
expects: matrix B replicates the outcome across every feature column, so
feature-wise correlation reduces exactly to `corr(feature_i, outcome)`.

This is a deliberate encoding, recorded as such in `broadcast.json`. Note
matrix B is about the same size on disk as matrix A — the cost of expressing a
vector comparison on a matrix-vs-matrix interface.

## CLI 3 — `gcorr_run.py`

Upload → run → poll → download → provenance. All tool parameters exposed
(`--method`, `--alternative`, `--alpha`, `--min-pairs`, `--delimiter`,
`--id-column`, `--feature-start`, `--transform`, `--tool-id`).

Optional regression check against any local reference table with configurable
columns:

```bash
--compare-to ref.tsv --ref-id-col probe_id --ref-stat-col rho \
--ref-p-col p --ref-q-col q_BH --fail-on-mismatch
```

`--fail-on-mismatch` exits non-zero, so this drops into CI.

### Known limitation: the agreement gate misreports on tie-heavy data

`AGREEMENT: FAIL` on a tie-heavy dataset **needs reading, not trusting**. Two
components of the check are not tie-aware:

1. **`top1000_overlap` compares rank order.** Cohort B has only 1,929 distinct
   p-values among 8,901 tests, so ranks ~130–1000 are one enormous tie block
   ordered arbitrarily. Overlap reads 128/1000 while the underlying statistics
   agree to 5e-07. Compared as *threshold sets* the agreement is exact:

   | threshold | stored | Galaxy | overlap | symmetric difference |
   |---|---|---|---|---|
   | p<0.001 | 0 | 0 | 0 | **0** |
   | p<0.01 | 12 | 12 | 12 | **0** |
   | p<0.05 | 125 | 125 | 125 | **0** |

2. **`max_abs_q_diff` compares BH across different denominators.** Undefined
   tests (constant features) are excluded by Galaxy (n=8,901) but may be
   included as q=1.0 by a local reference (n=8,914). A definitional difference,
   not an arithmetic one.

When the gate fails, check `max_abs_statistic_diff` and `max_abs_p_diff` first.
If those are ~1e-07 the implementations agree and the failure is an artifact.

## Worked example — the YF-17D trial-1 analysis

```bash
D=hypothesis2omics/data

python3 galaxycorr/gcorr_prep.py \
  --matrix   $D/galaxy_file_input/GSE13485_intensities.csv \
  --manifest $D/validator_immport/sample_manifest.tsv \
  --outcome  $D/galaxy_file_input/ImmPort_neut_ab_titer_results.tsv \
  --sample-col repository_accession --subject-col subject_accession \
  --time-col study_time_collected --timepoint 7 --baseline 0 \
  --where arm_accession=ARM4368 \
  --outcome-subject-col subject_accession --outcome-value-col value_preferred \
  --outcome-time-col study_time_collected --outcome-timepoint 60 \
  --outcome-where study_accession=SDY1264 \
  --outcome-transform log2 --out out/trial1

python3 galaxycorr/gcorr_broadcast.py \
  --features out/trial1.features.tsv --outcome out/trial1.outcome.tsv \
  --out out/trial1

python3 galaxycorr/gcorr_run.py \
  --matrix-a out/trial1.matA.tsv --matrix-b out/trial1.matB.tsv \
  --out out/trial1 \
  --compare-to yf17d/out/corr_A_d60arm__FC_d7-d0__log2titer.tsv \
  --ref-id-col probe_id --ref-stat-col rho --ref-p-col p --ref-q-col q_BH
```

The within-arm-rank variant (n=25) is the same, swapping
`--where arm_accession=ARM4368` for nothing, dropping `--outcome-timepoint`,
and using `--outcome-transform rank --rank-within arm_accession`.

## Test it yourself

Every command below was executed verbatim on 2026-09-18 and the printed
expectations are the observed output. Tests 0–5 are local and offline;
tests 6–7 submit jobs to Galaxy.

Set these once:

```bash
export GCORR_DATA=/nfs/lambda_stor_01/data/avasan/omics_agents/hypothesis2omics/data
export GCORR_REF=/nfs/lambda_stor_01/data/avasan/omics_agents/yf17d
mkdir -p /tmp/gcorr_test && cd /tmp/gcorr_test
```

### Test 0 — preflight

```bash
for c in gcorr-prep gcorr-broadcast gcorr-run; do
  printf '%-16s %s\n' "$c" "$(command -v $c || echo MISSING)"
done
python3 -c "import bioblend; print('bioblend', bioblend.__version__)"
```

All three must resolve (to `~/.local/bin/` for a `--user` install). `bioblend`
is needed only by test 6–7.

### Test 1 — cohort A: a dataset with no ties

```bash
gcorr-prep \
  --matrix   $GCORR_DATA/galaxy_file_input/GSE13485_intensities.csv \
  --manifest $GCORR_DATA/validator_immport/sample_manifest.tsv \
  --outcome  $GCORR_DATA/galaxy_file_input/ImmPort_neut_ab_titer_results.tsv \
  --sample-col repository_accession --subject-col subject_accession \
  --time-col study_time_collected --timepoint 7 --baseline 0 \
  --where arm_accession=ARM4368 \
  --outcome-subject-col subject_accession --outcome-value-col value_preferred \
  --outcome-time-col study_time_collected --outcome-timepoint 60 \
  --outcome-where study_accession=SDY1264 \
  --outcome-transform log2 --out cohortA

gcorr-broadcast --features cohortA.features.tsv \
                --outcome  cohortA.outcome.tsv --out cohortA
```

Expect **15 subjects x 20077 features**, `0 missing-value, 0 floor`.

### Test 2 — cohort B: different platform, floor filter, `--floor-scope all`

```bash
gcorr-prep \
  --matrix   $GCORR_DATA/galaxy_file_input/GSE13699_GPL6104_intensities.csv \
  --manifest $GCORR_DATA/validator_immport/sample_manifest.tsv \
  --outcome  $GCORR_DATA/galaxy_file_input/ImmPort_neut_ab_titer_results.tsv \
  --sample-col repository_accession --subject-col subject_accession \
  --time-col study_time_collected --timepoint 7 --baseline 0 \
  --where arm_accession=ARM4455 \
  --floor 7.0 --min-above 13 --floor-scope all \
  --outcome-subject-col subject_accession --outcome-value-col value_preferred \
  --outcome-time-col study_time_collected --outcome-timepoint 28 \
  --outcome-where study_accession=SDY1289 \
  --outcome-transform log2 --out cohortB

gcorr-broadcast --features cohortB.features.tsv \
                --outcome  cohortB.outcome.tsv --out cohortB
```

Expect **13 subjects x 8914 features** and
`floor: >7.0 in >=13 of 126 sample(s) [scope=all]`.

### Test 3 — the same run with `--floor-scope filtered`

Re-run test 2 with `--floor-scope filtered --out cohortB_filtered`.

Expect **8741 features** and a denominator of **93 sample(s)**. The 173-feature
difference is the whole point of the flag — same threshold, different
denominator.

### Test 4 — tie audit, and numeric agreement with the stored result

```bash
python3 /nfs/lambda_stor_01/data/avasan/omics_agents/galaxycorr/check_ties.py \
  cohortA.features.tsv

python3 /nfs/lambda_stor_01/data/avasan/omics_agents/galaxycorr/check_ties.py \
  cohortB.features.tsv $GCORR_REF/out/corr_B__FC_d7-d0__log2_d28titer.tsv
```

Expect cohort A **0 (0.0%)** tied features, cohort B **4822 (54.1%)**, and for
cohort B against the stored table:

```
    max |delta rho|    = 0.0000
    median |delta rho| = 0.0000
    features shifting > 0.01 : 0 / 8914
```

That max of exactly 0.0000 on a 54%-tied dataset is the `%.17g` fix working. A
non-zero value here means matrix serialization has regressed.

### Test 5 — probe-ID set equality

```bash
tail -n +2 $GCORR_REF/out/corr_B__FC_d7-d0__log2_d28titer.tsv | cut -f1 | sort > stored_ids.txt
head -1 cohortB.features.tsv | tr '\t' '\n' | tail -n +2 | sort > new_ids.txt
cmp -s stored_ids.txt new_ids.txt && echo IDENTICAL || echo DIFFER
```

Expect `IDENTICAL` (8,914 probes).

### Test 6 — cohort A end-to-end on Galaxy (expect `PASS`)

```bash
gcorr-run \
  --matrix-a cohortA.matA.tsv --matrix-b cohortA.matB.tsv --out cohortA \
  --history-name "gcorr test [cohort A]" \
  --compare-to $GCORR_REF/out/corr_A_d60arm__FC_d7-d0__log2titer.tsv \
  --ref-id-col probe_id --ref-stat-col rho --ref-p-col p --ref-q-col q_BH
```

Expect `AGREEMENT: PASS`, max |Δstat| 4.9e-07, max |Δp| 5.0e-08,
max |Δq| 5.0e-08, top-1000 overlap **1000/1000**.

### Test 7 — cohort B end-to-end on Galaxy (expect `FAIL` — an artifact)

Re-run test 6 against the cohort B matrices and
`$GCORR_REF/out/corr_B__FC_d7-d0__log2_d28titer.tsv`.

Expect **`AGREEMENT: FAIL`** with max |Δstat| **5.0e-07**, max |Δp| **5.0e-08**,
but `max_abs_q_diff` 1.1e-03 and top-1000 overlap **128/1000**. This is the
known gate limitation documented under *CLI 3*, not a real disagreement — the
statistics agree to 5e-07 and the threshold sets match exactly. **A `FAIL` here
is the expected result today.**

### Verified runs (2026-09-18)

Ids read from the machine-written provenance JSONs and confirmed against the
Galaxy API, not transcribed from terminal output:

| test | history | job | state | verdict |
|---|---|---|---|---|
| 6 (cohort A) | `bbd44e69cb8906b57d3e4ed765156df1` | `bbd44e69cb8906b593e925af086a46d3` | `ok` | `PASS` |
| 7 (cohort B) | `bbd44e69cb8906b56dceedff06ed3d41` | `bbd44e69cb8906b516c6e19df1f2b08d` | `ok` | `FAIL` (artifact) |

Also verified, not reproduced by the commands above:

- **Cohort A numeric agreement.** matA/matB agree with the stored
  `yf17d/galaxy_in/` matrices to max |Δ| **1.8e-15** (matB exactly 0), headers
  identical. These are no longer *byte*-identical: `%.17g` emits more digits
  than the `%.12g` used when those files were written. Numeric comparison
  replaced byte-identity as the regression check.
- **Genericity.** Clean run on a synthetic mouse RNA-seq dataset (comma matrix,
  different column names, replicate collapse, floor filter, `--rank-within
  batch`), with within-group percentile ranks checked against an independent
  recomputation.
- **Error paths.** Bad column name, log2 of non-positive values, `--rank-within`
  without rank transform, zero subject overlap, and a missing matrix file each
  exit with an actionable message.

## Scope limits

- `gcorr-run`'s input schema targets `featurewise_correlation`. `--tool-id`
  re-points the version, but a different tool with a different parameter
  schema would need new wiring.
- Study-design decisions (which arm, which timepoint, what floor) are **flags
  you supply**, not inference. These CLIs remove the plumbing, not the
  judgement.
- `significant_count 0` is printed with a warning: agreement between
  implementations confirms arithmetic, never a finding.
